package dev.lelonio.square.data

import android.content.Context
import androidx.annotation.StringRes
import dev.lelonio.square.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * What a download should be, and when one is allowed to happen.
 *
 * Separate from [QualityStore] on purpose. Streaming quality is a running
 * negotiation with the connection — [Quality.Auto] moves it up and down as the
 * link changes — and a download is the opposite: it happens once, it is kept,
 * and dropping it to 96 kbps because the Wi-Fi was briefly poor would leave a
 * bad copy on the phone for good. So there is no Auto here.
 */
enum class DownloadQuality(
    val key: String,
    @StringRes val label: Int,
    val kbps: Int,
) {
    High("high", R.string.quality_high, 320),
    Medium("medium", R.string.quality_medium, 160),
    Low("low", R.string.quality_low, 96),
    ;

    companion object {
        fun from(key: String?): DownloadQuality =
            entries.firstOrNull { it.key == key } ?: High
    }
}

class DownloadSettingsStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    private val _quality = MutableStateFlow(DownloadQuality.from(prefs.getString(KEY_QUALITY, null)))

    /** Defaults to the best available: a download is kept, so it may as well be good. */
    val quality: StateFlow<DownloadQuality> = _quality.asStateFlow()

    fun setQuality(value: DownloadQuality) {
        if (value == _quality.value) return
        _quality.value = value
        prefs.edit().putString(KEY_QUALITY, value.key).apply()
    }

    private val _wifiOnly = MutableStateFlow(prefs.getBoolean(KEY_WIFI_ONLY, false))

    /**
     * Off by default: until the listener chooses, a download simply uses the
     * connection the phone has, Wi-Fi when it is on Wi-Fi and mobile data when
     * it is not. Someone who wants downloads kept to Wi-Fi turns it on, and
     * that choice is kept.
     */
    val wifiOnly: StateFlow<Boolean> = _wifiOnly.asStateFlow()

    fun setWifiOnly(value: Boolean) {
        if (value == _wifiOnly.value) return
        _wifiOnly.value = value
        prefs.edit().putBoolean(KEY_WIFI_ONLY, value).apply()
    }

    private val _autoDownload = MutableStateFlow(prefs.getBoolean(KEY_AUTO, false))

    /**
     * Off by default. When it is on, every song that has been listened to for 15
     * seconds is kept on the phone, in Downloaded songs, without being asked for.
     * The listener turns it on here or, with the change of dress, by holding the
     * home icon (see AppSwitch): the one goes on with the other, and off again
     * when the dress is changed back.
     */
    val autoDownload: StateFlow<Boolean> = _autoDownload.asStateFlow()

    fun setAutoDownload(value: Boolean) {
        if (value == _autoDownload.value) return
        _autoDownload.value = value
        prefs.edit().putBoolean(KEY_AUTO, value).apply()
    }

    private val _autoSeconds = MutableStateFlow(prefs.getInt(KEY_AUTO_SECONDS, DEFAULT_AUTO_SECONDS).coerceIn(1, MAX_AUTO_SECONDS))

    /** How many seconds a song has to be listened to before the automatic download keeps it: 15 unless changed, up to 60. */
    val autoDownloadSeconds: StateFlow<Int> = _autoSeconds.asStateFlow()

    fun setAutoDownloadSeconds(value: Int) {
        val seconds = value.coerceIn(1, MAX_AUTO_SECONDS)
        if (seconds == _autoSeconds.value) return
        _autoSeconds.value = seconds
        prefs.edit().putInt(KEY_AUTO_SECONDS, seconds).apply()
    }

    private val _keepLiked = MutableStateFlow(prefs.getBoolean(KEY_KEEP_LIKED, false))

    /**
     * Off by default. When it is on, a song is put to Downloaded songs the moment
     * it is liked, by any of the ways of liking one (see KeepWhatIsLiked). Only
     * offered, and only working, while the automatic download is off.
     */
    val keepLiked: StateFlow<Boolean> = _keepLiked.asStateFlow()

    fun setKeepLiked(value: Boolean) {
        if (value == _keepLiked.value) return
        _keepLiked.value = value
        prefs.edit().putBoolean(KEY_KEEP_LIKED, value).apply()
    }

    private val _likedSongs = MutableStateFlow(prefs.getBoolean(KEY_LIKED, false))

    /** Whether the whole of Liked Songs is kept offline, and kept in step. */
    val downloadLikedSongs: StateFlow<Boolean> = _likedSongs.asStateFlow()

    fun setDownloadLikedSongs(value: Boolean) {
        if (value == _likedSongs.value) return
        _likedSongs.value = value
        prefs.edit().putBoolean(KEY_LIKED, value).apply()
    }

    private val _offline = MutableStateFlow(prefs.getBoolean(KEY_OFFLINE, false))

    /**
     * The listener's own switch, which beats anything the app works out for
     * itself. Persisted, so a phone put into offline mode is still in it after
     * a restart — the alternative is an app that quietly starts streaming again
     * on mobile data overnight.
     */
    val offlineMode: StateFlow<Boolean> = _offline.asStateFlow()

    fun setOfflineMode(value: Boolean) {
        if (value == _offline.value) return
        _offline.value = value
        prefs.edit().putBoolean(KEY_OFFLINE, value).apply()
    }

    private companion object {
        const val FILE_NAME = "square_downloads"
        const val KEY_QUALITY = "quality"
        const val KEY_WIFI_ONLY = "wifi_only"
        const val KEY_LIKED = "liked_songs"
        const val KEY_AUTO = "auto_download"
        const val KEY_AUTO_SECONDS = "auto_download_seconds"
        const val KEY_KEEP_LIKED = "keep_liked"
        const val DEFAULT_AUTO_SECONDS = 15
        const val MAX_AUTO_SECONDS = 60
        const val KEY_OFFLINE = "offline_mode"
    }
}
