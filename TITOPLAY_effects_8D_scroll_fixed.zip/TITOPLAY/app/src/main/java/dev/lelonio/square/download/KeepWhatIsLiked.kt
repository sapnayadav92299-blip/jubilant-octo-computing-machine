package dev.lelonio.square.download

import dev.lelonio.square.SquareApplication
import dev.lelonio.square.data.CatalogTrack
import dev.lelonio.square.playback.OfflineMode

/**
 * A song the listener has just liked, put to Downloaded songs: the switch "download
 * the songs I like" in Settings.
 *
 * It takes every kind of like there is, and is called from each of them: the
 * heart in the player, the heart in the notification and the lock screen, and the
 * double tap on the cover, which is the like kept on the phone for the songs of
 * a service that has no account to like them on.
 *
 * It does nothing when the automatic download is on: that one keeps every song
 * that has been listened to for long enough, a liked one included, and it is why
 * this switch is only shown with that one off.
 */
object KeepWhatIsLiked {

    suspend fun onLiked(app: SquareApplication, track: CatalogTrack) {
        val settings = app.downloadSettings
        if (!settings.keepLiked.value || settings.autoDownload.value) return
        val uri = track.uri
        // Songs that are already files on the phone are not downloaded again.
        if (uri.startsWith("local:") || track.localFile != null) return
        // Nothing to fetch a song with, and no way to ask again later.
        if (OfflineMode.active.value) return
        if (app.downloads.isDownloaded(uri) || app.downloads.isWanted(uri)) return
        app.downloads.addSingle(track)
        DownloadService.start(app)
    }
}
