package dev.lelonio.square.ui.settings

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import dev.lelonio.square.R

/**
 * The voice that speaks when the About page is opened: a couple of seconds, from
 * the file in res/raw/about_voice.mp3, played once each time the page is opened.
 *
 * It plays over whatever else is sounding rather than asking for the audio
 * focus, so it never makes the music stop or turn down: it is too short for that
 * to matter, and the player has no reason to be told about it. Leaving the page
 * before it has finished ends it.
 */
object AboutVoice {

    private var player: MediaPlayer? = null

    fun play(context: Context) {
        stop()
        runCatching {
            val app = context.applicationContext
            val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val voice = MediaPlayer.create(app, R.raw.about_voice, attributes, audio.generateAudioSessionId())
                ?: return@runCatching
            voice.setOnCompletionListener { stop() }
            voice.start()
            player = voice
        }
    }

    fun stop() {
        val voice = player ?: return
        player = null
        runCatching { voice.stop() }
        runCatching { voice.release() }
    }
}
